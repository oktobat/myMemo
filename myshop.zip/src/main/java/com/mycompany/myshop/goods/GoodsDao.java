package com.mycompany.myshop.goods;

import java.util.List;
import java.util.Map;

public interface GoodsDao {
	public long insertNewGoods(GoodsVo goodsVo);
	public int insertDetailImage(Map<String, Object> map);
	public List<GoodsVo> selectGoodsList(int pNum, int scale, String g_category);
	public int selectGoodsCount(String g_category);
	public int insertCart(Map<String, Integer> map);
	public int selectCartCount(int m_no);
	public List<CartVo> selectCartList(int m_no);
	public int updateCart(Map<String, Integer> map);
	public int deleteCartItem(long cart_no);
	public GoodsVo selectGoods(long g_no);
	public List<GoodsImageVo> selectImages(long g_no);
	public List<GoodsVo> selectSearchGoods(String keyword);
	public List<GoodsVo> selectMainGoods(String g_type);
	public int updateGoods(GoodsVo goodsVo);
	public int deleteGoodsImage(long img_no);
	public int updateImage(GoodsImageVo goodsImageVo);
	public int insertImage(GoodsImageVo goodsImageVo);
	public int deleteGoods(long g_no);
	public int deleteCheckedCart(List<Long> cartNoList);
	public List<CartVo> selectCheckoutList(List<Long> cartNos);
	public long insertOrder(OrderVo orderVo);
	public int insertOrderDetail(long orderNo, List<OrderDetailVo> orderDetailItems);
	public List<OrderVo> selectMyOrderList(int m_no);
	public List<OrderDetailVo> selectMyOrderDetailList(long order_no);
	public int updateGoodsInventory(OrderDetailVo orderDetailItem);
	public int selectCartItemQty(int m_no, long g_no);
	public int updateOrderDetailReviewed(long order_detail_no);
}
