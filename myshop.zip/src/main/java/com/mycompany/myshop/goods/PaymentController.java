package com.mycompany.myshop.goods;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.siot.IamportRestClient.IamportClient;
import com.siot.IamportRestClient.exception.IamportResponseException;
import com.siot.IamportRestClient.response.IamportResponse;
import com.siot.IamportRestClient.response.Payment;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Controller
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/payment")
public class PaymentController {
	
	@Autowired
	private OrderService orderService;
	
	private final RefundService refundService;
	
	private IamportClient iamportClient;
	
	@PostConstruct
	public void init() {					   // Rest API key     // REST API Secret
		this.iamportClient = new IamportClient("0810417338884670", "l57LYNshCXHl43VLVhILNha7TegpKBHGNuFGeOTxkm01lrgklNFvepw60fZf3YqWU5n2CVDOxaxEnvLa");
	}
	
	@ResponseBody
	@PostMapping("/verify/{img_uid}")
	public IamportResponse<Payment> paymentByImpUid(@PathVariable("img_uid") String imp_uid) throws IamportResponseException, IOException {
		IamportResponse<Payment> payment = iamportClient.paymentByImpUid(imp_uid);
		log.info("결제 요청 응답. 결제 내역 - 주문 번호: {}", payment.getResponse().getMerchantUid());
		return payment;
	}
	
	@ResponseBody
	@PostMapping(value="/orderRegister", consumes="application/json", produces="application/json")
	public ResponseEntity orderRegister(@RequestBody OrderVo orderVo, HttpSession session) throws Exception {
		List<OrderDetailVo> orderDetailItems = new ArrayList<>();
		List<CartVo> orderItems = new ArrayList<>();
		orderItems = (List<CartVo>) session.getAttribute("orderItems");
		List<Long> orderCartNos = new ArrayList<>();
		orderVo.setImg_url(orderItems.get(0).getImg_url());
		System.out.println(orderItems.toString());
		for (int i=0; i<orderItems.size(); i++) {
			OrderDetailVo orderDetailVo = new OrderDetailVo();
			orderDetailVo.setG_no(orderItems.get(i).getG_no());
			orderDetailVo.setOrder_qty(orderItems.get(i).getCart_qty());
			orderDetailVo.setG_name(orderItems.get(i).getG_name());
			orderDetailVo.setG_price(orderItems.get(i).getG_price());
			orderDetailVo.setImg_url(orderItems.get(i).getImg_url());
			
			orderDetailItems.add(orderDetailVo);
			orderCartNos.add(orderItems.get(i).getCart_no());
		}
		int count = orderItems.size();
		int orderAmount = orderVo.getOrder_amount();
		int shippingCost = orderVo.getShipping_cost();
		orderVo.setItem_count(count);
		orderVo.setFinal_amount(orderAmount+shippingCost);
		String itemName = orderItems.get(0).getG_name();
		if (count>1) {
			orderVo.setItem_name(itemName+" 외 "+(count-1)+"건");
		} else {
			orderVo.setItem_name(itemName);
		}
		System.out.println(orderDetailItems.toString());
		try { 
			Map<String, String> map = new HashMap<>();
			int result = orderService.orderRegister(orderVo, orderDetailItems, orderCartNos);
			map.put("message", "성공");
			return new ResponseEntity<>(map, HttpStatus.OK);
		} catch (RuntimeException e) {
			// 결제취소
			log.info("주문 상품 환불 진행 : 주문 번호 {}", orderVo.getOrder_id());
			String token = null;
			try { 
				token = refundService.getToken("0810417338884670", "l57LYNshCXHl43VLVhILNha7TegpKBHGNuFGeOTxkm01lrgklNFvepw60fZf3YqWU5n2CVDOxaxEnvLa");
			} catch (IOException e1) {
				e1.printStackTrace();
			}
			try { 
				refundService.refundRequest(token, orderVo.getOrder_id(), e.getMessage());
			} catch (IOException e2) { 
				e2.printStackTrace();
			}
			return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
		}
	}
	
	
	@ResponseBody
	@PostMapping(value="/paymentCancel", produces="application/json")
	public ResponseEntity paymentCancel(@RequestParam("order_id") String order_id) throws Exception {
	  // 결제취소
		log.info("주문 상품 환불 진행 : 주문 번호 {}", order_id);
		String token = null;
		try { 
			token = refundService.getToken("0810417338884670", "l57LYNshCXHl43VLVhILNha7TegpKBHGNuFGeOTxkm01lrgklNFvepw60fZf3YqWU5n2CVDOxaxEnvLa");
		} catch (IOException e1) {
			e1.printStackTrace();
		}
		try { 
			refundService.refundRequest(token, order_id, "결제취소");
		} catch (IOException e2) { 
			e2.printStackTrace();
		}
		Map<String, String> map = new HashMap<>();
		map.put("message", "결제취소");
		return new ResponseEntity<>(map, HttpStatus.OK);
	}
	

	@GetMapping("/complete")
	public String complete() {
		String nextPage = "goods/payment_complete";
		return nextPage;
	}
	
	
}
