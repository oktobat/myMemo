package com.mycompany.myshop.goods;

import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class OrderService {
	
	@Autowired
	private OrderRegisterService orderRegisterService;
	
	@Autowired
    private OrderDetailService orderDetailService;
	
	@Autowired
	private CartService cartService;
	
	@Autowired
	private GoodsService goodsService;

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {RuntimeException.class, IllegalArgumentException.class, Exception.class})
    public int orderRegister(OrderVo orderVo, List<OrderDetailVo> orderDetailItems, List<Long> orderCartNos) throws Exception {
        try {
        	int totalUpdated = 0;
            
            // for문을 통해 하나씩 아이템을 업데이트
            for (OrderDetailVo orderDetailItem : orderDetailItems) {
                int result = goodsService.updateGoodsInventory(orderDetailItem);  // 아이템 하나씩 전달
                if (result == 0) {
                    throw new RuntimeException("재고 업데이트 실패: 상품 번호 " + orderDetailItem.getG_no());
                }
                totalUpdated += result;  // 성공적으로 업데이트된 갯수 누적
            }
        	System.out.println(totalUpdated);
        	long orderNo = orderRegisterService.insertRegisterOrder(orderVo);
            orderDetailService.insertOrderDetail(orderNo, orderDetailItems);
            cartService.deleteCart(orderCartNos);
            return totalUpdated;
	    } catch (RuntimeException e1) {
	        log.error("Insert error", e1);
	        throw e1;
	    } catch (Exception e2) {
	        log.error("Insert error", e2);
	        throw e2;
	    } 
        
    }
}
