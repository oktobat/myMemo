package com.mycompany.myshop.goods;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class OrderRegisterService {
	
	@Autowired
	private GoodsDao goodsDao;

	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {RuntimeException.class, IllegalArgumentException.class, Exception.class})
	public long insertRegisterOrder(OrderVo orderVo) throws Exception {
		try {
	        long result = goodsDao.insertOrder(orderVo);
	        return result;
	    } catch (RuntimeException e) {
	        log.error("Insert error", e);
	        throw e;
	    }
	}
	
}
