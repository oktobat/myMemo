package com.mycompany.myshop.goods;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mycompany.myshop.member.MemberVo;

@Controller
@RequestMapping("/goods")
public class GoodsController {

	@Autowired
	private GoodsService goodsService;
	
	@GetMapping("/registerGoodsForm")
	public String registerGoodsForm(HttpSession session) throws Exception {
		session.setAttribute("currentCategory", "");
		String nextPage = "goods/register_goods_form";
		return nextPage;
	}
	
	@GetMapping("/categoryList")
	public String categoryList(@RequestParam("cate") String g_category, HttpSession session, Model model) throws Exception {
		String nextPage = "goods/goods_list";
		String title = null;
		switch (g_category) {
			case "mealKit" : title = "밀키트 Meal Kits"; break;
			case "vegetable" : title = "채소 Vegetables"; break;
			case "sideDishe" : title = "밑반찬 Side Dishes"; break;
			case "lunchBox" : title = "도시락 Meal Boxes"; break;
			case "mainDishe" : title = "일품요리 Main Dishes"; break;
			case "soupStew" : title = "국.찌개 Soup & Stew"; break;
			case "friedPancake" : title = "튀김.전 Fried & Pancake"; break;
			case "giftCoupon" : title = "상품권 Gift Coupon"; break;
		}
		session.setAttribute("currentCategory", g_category);
		session.setAttribute("g_title", title);
		model.addAttribute("currentTitle", title);
		return nextPage;
	}
	
	@GetMapping("/cartList")
	public String cartList(HttpSession session, Model model) {
		String nextPage = "goods/cart_list";
		session.setAttribute("currentCategory", "");
		MemberVo mvo = (MemberVo) session.getAttribute("loginedMemberVo");
		if (mvo!=null) {
			int m_no = mvo.getM_no();
			List<CartVo> cartList = goodsService.cartList(m_no);
			model.addAttribute("cartVos", cartList);
		}
		return nextPage;
	}
	
	@GetMapping("/detailInfo")
	public String detailInfo(@RequestParam("g_no") long g_no, Model model) {
		String nextPage = "goods/goods_detail_info";
		GoodsVo goodsVo = goodsService.detailInfo(g_no);
		model.addAttribute("goodsVo", goodsVo);
		return nextPage;
	}
	
	@PostMapping("/searchGoods")
	public String searchGoods(@RequestParam("keyword") String keyword, Model model) {
		String nextPage = "goods/goods_search_list";
		List<GoodsVo> searchList = new ArrayList<>();
		searchList = goodsService.searchGoods(keyword);
		model.addAttribute("searchList", searchList);
		return nextPage; 
	}
	
	@GetMapping("/modifyGoodsForm")
	public String modifyGoodsForm(@RequestParam("g_no") long g_no, Model model) {
		String nextPage = "goods/modify_goods_form";
		GoodsVo goodsVo = goodsService.detailInfo(g_no);
		model.addAttribute("goodsVo", goodsVo);
		return nextPage;
	}
	
	@PostMapping("/checkoutList")
	public String checkoutList(@RequestParam("cart_no") List<Long> cartNos, Model model, HttpSession session) {
		String nextPage = "goods/checkout_list";
		List<CartVo> checkoutItems = goodsService.checkoutList(cartNos);
		session.setAttribute("orderItems", checkoutItems);
		model.addAttribute("checkoutItems", checkoutItems);
		return nextPage;
	}
	
	@GetMapping("/myOrderList")
	public String myOrderList(HttpSession session, Model model) {
		String nextPage = "goods/my_order_list";
		MemberVo mvo = (MemberVo) session.getAttribute("loginedMemberVo");
		if (mvo!=null) {
			int m_no = mvo.getM_no();
			List<OrderVo> myOrderList = goodsService.myOrderList(m_no);
			model.addAttribute("orderVos", myOrderList);
		}
		return nextPage;
	}
	
	@GetMapping("/myOrderDetail")
	public String myOrderDetail(@RequestParam("order_no") long order_no, Model model) {
		String nextPage = "goods/my_order_detail";
		List<OrderDetailVo> myOrderDetailList = goodsService.myOrderDetail(order_no);
		model.addAttribute("orderDetailVos", myOrderDetailList);
		return nextPage;
	}
	
	
	@PostMapping("/checkoutItem")
	public String checkoutItem(CartVo cartVo, Model model, HttpSession session) {
		String nextPage = "goods/checkout_list";
		List<CartVo> checkoutItem = new ArrayList<>();
		checkoutItem.add(cartVo);
		session.setAttribute("orderItems", checkoutItem);
		model.addAttribute("checkoutItems", checkoutItem);
		return nextPage;
	}
	
	
}
