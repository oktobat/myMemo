package com.mycompany.myshop.goods;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class GoodsImageVo {
	private long img_no;
	private long g_no;
	private String img_url;
	private Timestamp img_reg_date;
	private Timestamp img_mod_date;
}
