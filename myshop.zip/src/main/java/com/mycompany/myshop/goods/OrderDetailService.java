package com.mycompany.myshop.goods;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
@Transactional
public class OrderDetailService {
	
	@Autowired
	private GoodsDao goodsDao;
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {RuntimeException.class, Exception.class})
    public int insertOrderDetail(long orderNo, List<OrderDetailVo> orderDetailItems) throws Exception {
		try {
			// 강제로 예외 발생
	        if (orderDetailItems.isEmpty()) {
	            throw new RuntimeException("Order detail items are empty");
	        }
	        int result = goodsDao.insertOrderDetail(orderNo, orderDetailItems);
	        return result;
	    } catch (RuntimeException e) {
	        log.error("Insert error", e);
	        throw new RuntimeException("Order detail fail");
	    }
     }
	
}
