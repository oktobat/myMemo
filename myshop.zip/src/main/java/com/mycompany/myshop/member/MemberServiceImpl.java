package com.mycompany.myshop.member;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;

@Service
public class MemberServiceImpl implements MemberService {

	@Autowired
	private MemberDao memberDao;
	
	@Override
	public int joinConfirm(MemberVo memberVo) throws DataAccessException {
		return memberDao.insertMember(memberVo);
	}

	@Override
	public Map<String, Object> loginConfirm(MemberVo memberVo) throws DataAccessException {
		return memberDao.selectMember(memberVo);
	}

	@Override
	public int modifyMemberConfirm(MemberVo memberVo) throws DataAccessException {
		return memberDao.updateMember(memberVo);
	}

	@Override
	public int removeMemberConfirm(int m_no) throws DataAccessException {
		return memberDao.deleteMember(m_no);
	}

}
