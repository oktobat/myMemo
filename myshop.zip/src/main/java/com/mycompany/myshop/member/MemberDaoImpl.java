package com.mycompany.myshop.member;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Repository;

@Repository
public class MemberDaoImpl implements MemberDao {

	@Autowired
	private SqlSession sqlSession;
	
	@Autowired
	private PasswordEncoder passwordEncoder;
	
	@Override
	public int insertMember(MemberVo memberVo) {
		int result = -1;
		String password = passwordEncoder.encode(memberVo.getM_pw());
		memberVo.setM_pw(password);
		result = sqlSession.insert("mapper.member.insertMember", memberVo);
		return result;
	}

	@Override
	public Map<String, Object> selectMember(MemberVo memberVo) {
		Map<String, Object> map = new HashMap<>();
		List<MemberVo> findMembers = new ArrayList<>();
		findMembers = sqlSession.selectList("mapper.member.selectMember", memberVo.getM_email());
		if (findMembers.size()>0) {
			if (passwordEncoder.matches(memberVo.getM_pw(), findMembers.get(0).getM_pw() )) {
				map.put("findMember", findMembers.get(0));
			} else {
				map.put("findMember", null);
				map.put("message", "비밀번호가 틀립니다.");
			}
		} else {
			map.put("findMember", null);
			map.put("message", "계정이 존재하지 않습니다.");
		}
		return map;
	}

	@Override
	public int updateMember(MemberVo memberVo) {
		int result = -1;
		String password = passwordEncoder.encode(memberVo.getM_pw());
		memberVo.setM_pw(password);
		result = sqlSession.update("mapper.member.updateMember", memberVo);
		return result;
	}

	@Override
	public int deleteMember(int m_no) {
		return sqlSession.delete("mapper.member.deleteMember", m_no);
	}
	
}
