package com.mycompany.myshop.member;

public enum LoginType {
	LOCAL,
	GOOGLE,
	KAKAO
}
