package com.mycompany.myshop.review;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mycompany.myshop.goods.GoodsDao;

@Service
public class ReviewServiceImpl implements ReviewService {

	@Autowired
	private ReviewDao reviewDao;
	
	@Autowired
	private GoodsDao goodsDao;

	@Override
	@Transactional
	public int registerReviewConfirm(ReviewVo reviewVo, List<String> images) throws DataAccessException {
		int review_no = reviewDao.insertNewReview(reviewVo);
		if (review_no <= 0) {
            throw new RuntimeException("리뷰 삽입 실패");
        }
		int reviewed = goodsDao.updateOrderDetailReviewed(reviewVo.getOrder_detail_no());
		System.out.println("리뷰번호 : "+review_no);
		System.out.println("이미지스:"+images);
		if ( images.size()>0 && review_no>0) {
			Map<String, Object> reviewMap = new HashMap<>();
			reviewMap.put("images", images);
			reviewMap.put("review_no", review_no);
			int result = reviewDao.insertReviewImage(reviewMap);
			if (result <= 0) {
	            throw new RuntimeException("리뷰 이미지 삽입 실패");
	        }
		}
		return review_no;
	}
	
	@Override
	public int removeReviewConfirm(int review_no) throws DataAccessException {
		return reviewDao.deleteReview(review_no);
	}
	
	@Override
	@Transactional
	public void modifyReviewConfirm(ReviewVo reviewVo, List<String> images) throws DataAccessException {
		int updateCount = reviewDao.updateReview(reviewVo);
		System.out.println("이미지스:"+images);
		if ( images.size()>0 && updateCount>0) {
			Map<String, Object> reviewMap = new HashMap<>();
			reviewMap.put("images", images);
			reviewMap.put("review_no", reviewVo.getReview_no());
			int result = reviewDao.insertReviewImage(reviewMap);
			if (result <= 0) {
	            throw new RuntimeException("리뷰 이미지 삽입 실패");
	        }
		}
		
	}

	@Override
	public List<ReviewVo> photoReviewData(int pNum, int scale, long g_no) throws DataAccessException {
		return reviewDao.selectPhotoReviewList(pNum, scale, g_no);	
	}

	@Override
	public int photoReviewCount(long g_no) throws DataAccessException {
		return reviewDao.selectPhotoReviewCount(g_no);
	}

	@Override
	public List<ReviewVo> textReviewData(int pNum, int scale, long g_no) throws DataAccessException {
		return reviewDao.selectTextReviewList(pNum, scale, g_no);	
	}

	@Override
	public int textReviewCount(long g_no) throws DataAccessException {
		return reviewDao.selectTextReviewCount(g_no);
	}

	@Override
	public List<ReviewVo> myReviewList(int m_no) throws DataAccessException {
		return reviewDao.selectMyReviewList(m_no);
	}

	
}
