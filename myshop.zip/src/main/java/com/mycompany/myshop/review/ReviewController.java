package com.mycompany.myshop.review;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.mycompany.myshop.member.MemberVo;
import com.mycompany.myshop.util.MultiUploadFileService;
import com.mycompany.myshop.util.PageVo;

@Controller
@RequestMapping("/review")
public class ReviewController {

	@Autowired
	private MultiUploadFileService multiUploadFileService;
	
	@Autowired
	private ReviewService reviewService;
	
	@ResponseBody
	@PostMapping(value="/registerReviewConfirm")
	public ResponseEntity<Integer> registerReviewConfirm(ReviewVo reviewVo, @RequestPart(value="file", required=false) List<MultipartFile> files, HttpSession session) throws Exception {
		MemberVo mvo = (MemberVo) session.getAttribute("loginedMemberVo");
		reviewVo.setM_no(mvo.getM_no());
		List<String> imageFileList = new ArrayList<>();
		int review_no = 0;
		try {
			if (files!=null && !files.isEmpty()) {
				imageFileList = multiUploadFileService.multiUpload(files);
			}
		} catch(Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(-1, HttpStatus.BAD_REQUEST);
		}
		
		try {
			review_no = reviewService.registerReviewConfirm(reviewVo, imageFileList);
			return new ResponseEntity<>(review_no, HttpStatus.OK);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(0, HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	
	// 리뷰 삭제
	@ResponseBody
	@PostMapping(value="/removeReviewConfirm")
	public ResponseEntity<Integer> removeReviewConfirm(@RequestParam("review_no") int review_no) throws Exception {
		int result = reviewService.removeReviewConfirm(review_no);
		return new ResponseEntity<>(result, HttpStatus.OK);
	}
	
	@ResponseBody
	@PostMapping(value="/modifyReviewConfirm", produces="text/plain; charset=UTF-8")
	public String modifyReviewConfirm(ReviewVo reviewVo, @RequestPart(value="file", required=false) List<MultipartFile> files, HttpSession session) throws Exception {
		List<String> imageFileList = new ArrayList<>();
		
		try {
			if (files!=null && !files.isEmpty()) {
				imageFileList = multiUploadFileService.multiUpload(files);
			}
		} catch(Exception e) {
			e.printStackTrace();
	        return "파일 업로드 실패";
		}
		
		try {
			reviewService.modifyReviewConfirm(reviewVo, imageFileList);
			return "성공";
		} catch (Exception e) {
			e.printStackTrace();
			return "실패";
		}
	}
	
	
	@ResponseBody
	@GetMapping(value="/photoReviewData", produces="application/json")
	public Map<String, Object> photoReviewData(@RequestParam("pageGroup") int pageGroup, @RequestParam("pageNum") int pageNum, @RequestParam("g_no") long g_no) {
		int amount = 3;
		int pageNums = 10;
		Map<String, Object> map = new HashMap<>();
		List<ReviewVo> photoReviewList = reviewService.photoReviewData((pageNum-1)*amount, amount, g_no);
		int totArticles = reviewService.photoReviewCount(g_no);
		PageVo pageVo = new PageVo(pageGroup, pageNum, amount, pageNums, totArticles);
		map.put("photoReviewList", photoReviewList);
		map.put("totalCount", totArticles);
		map.put("pageVo", pageVo);
		return map;
	}
	
	@ResponseBody
	@GetMapping(value="/textReviewData", produces="application/json")
	public Map<String, Object> textReviewData(@RequestParam("pageGroup") int pageGroup, @RequestParam("pageNum") int pageNum, @RequestParam("g_no") long g_no) {
		int amount = 3;
		int pageNums = 10;
		Map<String, Object> map = new HashMap<>();
		List<ReviewVo> textReviewList = reviewService.textReviewData((pageNum-1)*amount, amount, g_no);
		int totArticles = reviewService.textReviewCount(g_no);
		PageVo pageVo = new PageVo(pageGroup, pageNum, amount, pageNums, totArticles);
		map.put("textReviewList", textReviewList);
		map.put("totalCount", totArticles);
		map.put("pageVo", pageVo);
		return map;
	}
	
	@GetMapping("/myReviewList")
	public String myReviewList(HttpSession session, Model model) {
		String nextPage = "review/my_review_list";
		MemberVo mvo = (MemberVo) session.getAttribute("loginedMemberVo");
		List<ReviewVo> myReviewList = reviewService.myReviewList(mvo.getM_no());
		model.addAttribute("myReviewList", myReviewList);
		return nextPage;
	}
	
}
