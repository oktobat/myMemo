package com.mycompany.myshop.review;

import java.util.List;
import java.util.Map;

public interface ReviewDao {
	public int insertNewReview(ReviewVo reviewVo);
	public int deleteReview(int review_no);
	public int updateReview(ReviewVo reviewVo);
	public int insertReviewImage(Map<String, Object> map);
	public List<ReviewVo> selectPhotoReviewList(int pNum, int scale, long g_no);
	public int selectPhotoReviewCount(long g_no);
	public List<ReviewVo> selectTextReviewList(int pNum, int scale, long g_no);
	public int selectTextReviewCount(long g_no);
	public List<ReviewVo> selectMyReviewList(int m_no);
	
}
